package com.example.android.tlewis_quakereport_starting_point;

public class Earthquake {

    private double mMagnitude;

    private String location;

    /** Time of the earthquake */
    private long mTimeInMilliseconds;

    private String mUrl;

    public Earthquake(double magnitude, String new_location, long timeInMilliseconds, String url){
        mMagnitude = magnitude;
        location = new_location;
        mTimeInMilliseconds = timeInMilliseconds;
        mUrl = url;
    }



    public String getLocation() {
        return location;
    }

    public long getTimeInMilliseconds() {
        return mTimeInMilliseconds;
    }

    public double getMagnitude() {
        return mMagnitude;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getUrl() {
        return mUrl;
    }

}
